document.addEventListener('DOMContentLoaded', () => {
  const listEl = document.getElementById('filterList');
  const form = document.getElementById('addForm');
  const groupInput = document.getElementById('filterGroup');
  const nameInput = document.getElementById('filterName');
  const queryInput = document.getElementById('filterQuery');
  const submitBtn = form.querySelector('button[type="submit"]');
  const cancelBtn = document.getElementById('cancelEdit');

  let editingIndex = null;

  function render(filters) {
    listEl.innerHTML = '';
    if (filters.length === 0) {
      listEl.innerHTML = '<div class="empty">Aún no tienes filtros guardados.</div>';
      return;
    }

    // Migración suave: filtros antiguos sin grupo caen en "General"
    const groups = {};
    filters.forEach((f, i) => {
      const g = f.group || 'General';
      if (!groups[g]) groups[g] = [];
      groups[g].push({ ...f, originalIndex: i });
    });

    chrome.storage.local.get({ openGroups: [] }, (data) => {
      const openGroups = data.openGroups;
      Object.keys(groups).sort().forEach((groupName) => {
        const details = document.createElement('details');
        details.dataset.group = groupName;
        if (openGroups.includes(groupName)) details.open = true;
        details.addEventListener('toggle', saveOpenState);

        const summary = document.createElement('summary');

        const summaryText = document.createElement('span');
        summaryText.textContent = `${groupName} (${groups[groupName].length})`;
        summary.appendChild(summaryText);

        const renameGroupBtn = document.createElement('button');
        renameGroupBtn.textContent = '✎';
        renameGroupBtn.className = 'groupEditBtn';
        renameGroupBtn.title = 'Renombrar grupo';
        renameGroupBtn.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          renameGroup(groupName);
        });
        summary.appendChild(renameGroupBtn);

        details.appendChild(summary);

        const body = document.createElement('div');
        body.className = 'groupBody';

        groups[groupName].forEach((f) => {
          const row = document.createElement('div');
          row.className = 'row';

          const btn = document.createElement('button');
          btn.textContent = f.name;
          btn.className = 'filterBtn';
          btn.title = f.query;
          btn.addEventListener('click', () => runFilter(f.query));

          const edit = document.createElement('button');
          edit.textContent = '✎';
          edit.className = 'editBtn';
          edit.title = 'Editar filtro';
          edit.addEventListener('click', () => startEdit(f.originalIndex, f));

          const del = document.createElement('button');
          del.textContent = '✕';
          del.className = 'delBtn';
          del.title = 'Eliminar filtro guardado';
          del.addEventListener('click', () => removeFilter(f.originalIndex));

          row.appendChild(btn);
          row.appendChild(edit);
          row.appendChild(del);
          body.appendChild(row);
        });

        details.appendChild(body);
        listEl.appendChild(details);
      });
    });
  }

  function saveOpenState() {
    const openGroups = [];
    document.querySelectorAll('details').forEach((d) => {
      if (d.open) openGroups.push(d.dataset.group);
    });
    chrome.storage.local.set({ openGroups });
  }

  function load() {
    chrome.storage.sync.get({ filters: [] }, (data) => render(data.filters));
  }

  function runFilter(query) {
    const url = 'https://mail.google.com/mail/u/0/#search/' + encodeURIComponent(query);
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tab = tabs[0];
      if (tab && tab.url && tab.url.includes('mail.google.com')) {
        chrome.tabs.update(tab.id, { url });
      } else {
        chrome.tabs.create({ url });
      }
    });
  }

  function removeFilter(index) {
    chrome.storage.sync.get({ filters: [] }, (data) => {
      const filters = data.filters;
      filters.splice(index, 1);
      chrome.storage.sync.set({ filters }, () => {
        if (editingIndex === index) cancelEdit();
        load();
      });
    });
  }

  function startEdit(index, f) {
    editingIndex = index;
    groupInput.value = f.group || 'General';
    nameInput.value = f.name;
    queryInput.value = f.query;
    submitBtn.textContent = 'Guardar cambios';
    cancelBtn.style.display = 'block';
    nameInput.focus();
  }

  function cancelEdit() {
    editingIndex = null;
    groupInput.value = '';
    nameInput.value = '';
    queryInput.value = '';
    submitBtn.textContent = '+ Añadir filtro';
    cancelBtn.style.display = 'none';
  }

  function renameGroup(oldName) {
    const newName = prompt('Nuevo nombre para el grupo:', oldName);
    if (newName === null) return; // cancelado
    const trimmed = newName.trim();
    if (!trimmed || trimmed === oldName) return;
    chrome.storage.sync.get({ filters: [] }, (data) => {
      const filters = data.filters.map((f) => {
        const g = f.group || 'General';
        return g === oldName ? { ...f, group: trimmed } : f;
      });
      chrome.storage.sync.set({ filters }, () => {
        // Actualiza también el estado de "abierto" guardado, si aplica
        chrome.storage.local.get({ openGroups: [] }, (d) => {
          const openGroups = d.openGroups.map((g) => (g === oldName ? trimmed : g));
          chrome.storage.local.set({ openGroups }, load);
        });
      });
    });
  }

  cancelBtn.addEventListener('click', cancelEdit);

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const group = groupInput.value.trim() || 'General';
    const name = nameInput.value.trim();
    const query = queryInput.value.trim();
    if (!name || !query) return;
    chrome.storage.sync.get({ filters: [] }, (data) => {
      const filters = data.filters;
      if (editingIndex !== null) {
        filters[editingIndex] = { group, name, query };
      } else {
        filters.push({ group, name, query });
      }
      chrome.storage.sync.set({ filters }, () => {
        cancelEdit();
        load();
      });
    });
  });

  load();
});
